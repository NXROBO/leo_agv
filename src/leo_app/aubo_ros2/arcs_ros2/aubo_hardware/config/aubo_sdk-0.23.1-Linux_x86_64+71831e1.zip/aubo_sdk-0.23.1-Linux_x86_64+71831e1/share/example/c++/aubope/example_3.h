#ifndef EXAMPLE_3_H
#define EXAMPLE_3_H

#include "AuboRobotMetaType.h"
#include "serviceinterface.h"

class Example_3
{
public:
    /**
     * @brief demo
     *
     * Joint motion
     */
    static void demo();

    static void Relative_demo();

    static void Relative_base_demo();
};

#endif // EXAMPLE_3_H
