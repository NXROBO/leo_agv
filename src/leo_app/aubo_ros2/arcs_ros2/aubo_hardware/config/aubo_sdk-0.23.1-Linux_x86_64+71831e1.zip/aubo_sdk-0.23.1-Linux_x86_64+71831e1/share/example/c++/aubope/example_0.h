#ifndef EXAMPLE_0_H
#define EXAMPLE_0_H

#include "AuboRobotMetaType.h"
#include "serviceinterface.h"

class Example_0
{
public:
    /**
     * @brief demo
     *
     * Use the SDK to build a control engineering for the simplest robotic arm
     */
    static void demo();
};

#endif // EXAMPLE_0_H
